package com.bankAccount.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bankAccount.exception.AccountException;
import com.cg.bankAccount.exception.AmountException;
import com.cg.bankAccount.exception.NameException;
import com.cg.bankAccount.exception.PhoneNumberException;
import com.cg.bankAccount.service.AccountServiceImpl;

public class BankTest {
	//These comprise of the passed test cases as well as the failure test cases which have been corrected
	@Test
	public void ValidateNameTrue() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validateName("Srinivas"));
	}
	@Test 
	public void ValidateName() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validateName("Srinivas"));
		assertEquals(false, as.validateName("Srinivas?1997"));
		assertEquals(false, as.validateName("25874"));
		assertEquals(false, as.validateName("Srinivas"));
	}
	
	@Test
	public void ValidatePhonNumberTrue() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validatePhoneNumber("9494499914"));
	}
	
	@Test
	public void ValidatePhoneNumber() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validatePhoneNumber("94944"));
		assertEquals(false, as.validatePhoneNumber("2587413690"));
		assertEquals(false, as.validatePhoneNumber("3698"));
		assertEquals(false, as.validatePhoneNumber("testing"));
		assertEquals(false, as.validatePhoneNumber("????"));
	}
	
	@Test
	public void ValidateAmountTrue() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("650"));
	}
	
	@Test 
	public void ValidateAmount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("654"));
		assertEquals(false, bs.validateAmount("-180"));
	}
	
	@Test
	public void ValidateAccountTrue() throws AccountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("876786"));
		
	}
	@Test 
	public void ValidateAccount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("7585"));
		assertEquals(false, bs.validateAmount("-876"));
	}
	

}
